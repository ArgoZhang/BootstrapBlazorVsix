﻿(function () {
    var setMvpFlag = function (link) {
        var mvpId = 'WT.mc_id=DT-MVP-5004174';
        var href = link.href;
        if (href.indexOf(mvpId) === -1) {
            if (href.indexOf('?') > -1) {
                href = href + '&' + mvpId;
            }
            else {
                href = href + '?' + mvpId;
            }
            link.href = href;
        }
    }

    var mo = new MutationObserver(function () {
        var links = document.querySelectorAll('a');
        for (var index = 0; index < links.length; index++) {
            var link = links[index];
            setMvpFlag(link);
        }
    });

    mo.observe(document, {
        childList: true,
        subtree: true
    });

    console.log('MVP docs learn registered');
})();