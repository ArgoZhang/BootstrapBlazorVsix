﻿(function () {
    var isFunction = function isFunction(obj) {
        return typeof obj === "function" && typeof obj.nodeType !== "number";
    };

    var setMvpFlag = function(link, href) {
        if (href.indexOf('?') > -1) {
            href = href + '&WT.mc_id=DT-MVP-5004174';
        }
        else {
            href = href + '?WT.mc_id=DT-MVP-5004174';
        }
        link.href = href;
    }

    document.addEventListener('click', function (e) {
        var link = e.target;
        var href = null;
        if (link.tagName === 'A') {
            href = link.href;
        }
        else if(link.parentNode.tagName === 'A') {
            href = link.parentNode.href;
            link = link.parentNode;
        }
        if (href && isFunction(href.indexOf)) {
            if (href.indexOf('#') > -1) {
                return;
            }
            setMvpFlag(link, href);
        }
    });

    console.log('MVP docs learn registered');
})();